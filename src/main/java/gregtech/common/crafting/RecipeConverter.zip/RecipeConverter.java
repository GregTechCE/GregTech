package gregtech.temp;

import gregtech.api.items.ToolDictNames;
import gregtech.api.items.metaitem.MetaItem;
import gregtech.api.items.metaitem.MetaItem.MetaValueItem;
import gregtech.api.unification.stack.UnificationEntry;
import gregtech.api.util.GTLog;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFileChooser;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

public class RecipeConverter {
    private static void convert() {

    }

    private final static String emptyRow = "   ";
    private final static String textShape = " P ";
    private static File folder;

    public static void start() {
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new java.io.File("."));
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnVal = fc.showSaveDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            folder = fc.getSelectedFile();
        }
        if (folder == null) {
            return;
        }
        convert();
    }

    @SuppressWarnings("rawtypes")
    private static void addShapedRecipe(String id, MetaValueItem output, Object... recipe) {
        recipe = finalizeRecipeInput(recipe);
        try {
            JsonObject o = new JsonObject();
            o.add("type", new JsonPrimitive("gregtech:metaitem_shaped"));
            JsonArray pattern = new JsonArray();
            for (int i = 0; i < 3; i++) {
                pattern.add(new JsonPrimitive((String) recipe[i]));
            }
            o.add("pattern", pattern);
            JsonObject keyo = new JsonObject();
            for (int i = 3; i < recipe.length; i += 2) {
                char key = Character.valueOf((char) recipe[i]);
                Object target = recipe[i + 1];
                JsonObject in = new JsonObject();
                if (target instanceof UnificationEntry) {
                    in.add("type", new JsonPrimitive("forge:ore_dict"));
                    in.add("ore", new JsonPrimitive(((UnificationEntry) target).orePrefix.toString() + ((UnificationEntry) target).material.toString()));
                } else if (target instanceof MetaValueItem) {
                    in.add("type", new JsonPrimitive("gregtech:metaitem"));
                    in.add("name", new JsonPrimitive(((MetaValueItem) target).unlocalizedName));
                } else if (target instanceof String) {
                    in.add("type", new JsonPrimitive("forge:ore_dict"));
                    in.add("ore", new JsonPrimitive((String) target));
                }
                keyo.add(String.valueOf(key), in);
            }

            o.add("key", keyo);
            JsonObject result = new JsonObject();
            result.add("name", new JsonPrimitive(output.unlocalizedName));
            o.add("result", result);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            File f = new File(folder, id + ".json");
            while (f.exists()) {
                id = id + "_alt";
                f = new File(folder, id + ".json");
            }
            FileWriter fw = new FileWriter(f);
            gson.toJson(o, fw);
            fw.flush();
            fw.close();
        } catch (Exception e) {
            GTLog.logger.error(e);
        }
    }

    @SuppressWarnings("rawtypes")
    private static void addShapelessRecipe(String id, MetaValueItem output, Object... recipe) {
        try {
            JsonObject o = new JsonObject();
            o.add("type", new JsonPrimitive("gregtech:metaitem_shapeless"));
            JsonArray ing = new JsonArray();
            for (int i = 0; i < recipe.length; i++) {
                JsonObject in = new JsonObject();
                Object target = recipe[i];
                if (target instanceof UnificationEntry) {
                    in.add("type", new JsonPrimitive("forge:ore_dict"));
                    in.add("ore", new JsonPrimitive(((UnificationEntry) target).orePrefix.toString() + ((UnificationEntry) target).material.toString()));
                } else if (target instanceof MetaValueItem) {
                    in.add("type", new JsonPrimitive("gregtech:metaitem"));
                    in.add("name", new JsonPrimitive(((MetaValueItem) target).unlocalizedName));
                }
                ing.add(in);
            }
            o.add("ingredients", ing);
            JsonObject result = new JsonObject();
            result.add("name", new JsonPrimitive(output.unlocalizedName));
            o.add("result", result);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            File f = new File(folder, id + ".json");
            while (f.exists()) {
                id = id + "_alt";
                f = new File(folder, id + ".json");
            }
            FileWriter fw = new FileWriter(f);
            gson.toJson(o, fw);
            fw.flush();
            fw.close();
        } catch (Exception e) {
            GTLog.logger.error(e);
        }
    }

    private static Object[] finalizeRecipeInput(Object... recipe) {
        for (byte i = 0; i < recipe.length; i++) {
            if (recipe[i] instanceof MetaItem.MetaValueItem) {
                recipe[i] = ((MetaItem<?>.MetaValueItem) recipe[i]);
            } else if (recipe[i] instanceof Enum) {
                recipe[i] = ((Enum<?>) recipe[i]).name();
            } else if (recipe[i] instanceof UnificationEntry) {
                recipe[i] = recipe[i].toString();
            } else if (!(recipe[i] instanceof ItemStack
                || recipe[i] instanceof Item
                || recipe[i] instanceof Block
                || recipe[i] instanceof String
                || recipe[i] instanceof Character
                || recipe[i] instanceof Boolean)) {
                throw new IllegalArgumentException(recipe.getClass().getSimpleName() + " type is not suitable for crafting input.");
            }
        }

        int idx = 0;
        ArrayList<Object> recipeList = new ArrayList<>(Arrays.asList(recipe));

        while (recipe[idx] instanceof String) {

            StringBuilder s = new StringBuilder((String) recipe[idx++]);

            while (s.length() < 3)
                s.append(" ");

            if (s.length() > 3)
                throw new IllegalArgumentException();

            for (char c : s.toString().toCharArray()) {
                switch (c) {
                    case 'b':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolBlade.name());
                        break;
                    case 'c':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolCrowbar.name());
                        break;
                    case 'd':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolScrewdriver.name());
                        break;
                    case 'f':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolFile.name());
                        break;
                    case 'h':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolHardHammer.name());
                        break;
                    case 'i':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolSolderingIron.name());
                        break;
                    case 'j':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolSolderingMetal.name());
                        break;
                    case 'k':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolKnife.name());
                        break;
                    case 'm':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolMortar.name());
                        break;
                    case 'p':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolDrawplate.name());
                        break;
                    case 'r':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolSoftHammer.name());
                        break;
                    case 's':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolSaw.name());
                        break;
                    case 'w':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolWrench.name());
                        break;
                    case 'x':
                        recipeList.add(c);
                        recipeList.add(ToolDictNames.craftingToolWireCutter.name());
                        break;
                }
            }
        }
        return recipeList.toArray();
    }
}
